let historyStack=[];
let generatedOTP="";

function showPage(id){

document.querySelectorAll(".page").forEach(p=>{
p.classList.remove("active");
});

document.getElementById(id).classList.add("active");

historyStack.push(id);

}


function goBack(){

historyStack.pop();
let prev=historyStack.pop();

if(prev){
showPage(prev);
}

}


function sendOTP(){

let email=document.getElementById("email").value;

if(email=="" || !email.includes("@gmail.com")){
alert("Enter valid Gmail");
return;
}

generatedOTP=Math.floor(1000+Math.random()*9000);

document.getElementById("otpDisplay").innerHTML="Demo OTP: "+generatedOTP;

document.getElementById("otpSection").style.display="block";

}


function verifyOTP(){

let entered=document.getElementById("otpInput").value;

if(entered==generatedOTP){

alert("Login Successful");

showPage("dashboard");

}
else{

alert("Incorrect OTP");

}

}



function encryptData(type){

let message=document.getElementById(type+"Message").value;
let key=document.getElementById(type+"Key").value;

if(message==""||key==""){

alert("Enter message and key");
return;

}

let encrypted=CryptoJS.AES.encrypt(message,key).toString();

document.getElementById(type+"Encrypted").value=encrypted;

let hash=CryptoJS.SHA256(message+key).toString();

document.getElementById(type+"Result").innerHTML=
"<b>Encrypted Text:</b><br>"+encrypted+
"<br><br><b>Hash:</b><br>"+hash;

}



function decryptData(type){

let encrypted=document.getElementById(type+"Encrypted").value;
let key=document.getElementById(type+"Key").value;

try{

let bytes=CryptoJS.AES.decrypt(encrypted,key);
let decrypted=bytes.toString(CryptoJS.enc.Utf8);

if(decrypted==""){
alert("Wrong key");
return;
}

document.getElementById(type+"Message").value=decrypted;

document.getElementById(type+"Result").innerHTML=
"<b>Decrypted Message:</b><br>"+decrypted;

}
catch{

alert("Decryption failed");

}

}



document.getElementById("audioFile")?.addEventListener("change",function(){

let file=this.files[0];
let url=URL.createObjectURL(file);

document.getElementById("audioPreview").src=url;

});


document.getElementById("videoFile")?.addEventListener("change",function(){

let file=this.files[0];
let url=URL.createObjectURL(file);

document.getElementById("videoPreview").src=url;

});